package service;

public interface PaymentService {
    boolean pay(double amount);
}
